# An example template for releasing extensions across all platforms. For this app we show how to build a simple browser history plugin
1 Chrome Extension : 
    #technology used : 1 frontend : html 5 and css 2 backend : javascript 3 Database : Firebase 
      cloud

2 Safari Extension : 
    #technology used : 1 frontend : html 5 and css 2 backend : swift 5.0 3 Database : Firebase 
      cloud 4 xcode version : minimum 13 5 iOS : 14

3 Web App And Api :
    #technology used : 1 frontend : html 5 and css 2 backend : Laravel 8.0 3 Database : 
      Firebase cloud

Details : It will track all the browsing history of users and save it to firebase realtime cloud database

 ![ComputerHistoryView](laptop-screenshot.gif)
 ![ComputerHistoryView](New-Recording.gif)
 ![PhoneHistoryView](iosview.gif)
