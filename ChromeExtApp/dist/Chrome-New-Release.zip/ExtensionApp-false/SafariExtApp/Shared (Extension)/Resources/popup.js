console.log("Hello World!", browser);
var currentlocation = window.location.href;
console.log(currentlocation);
